/**
 * WorkflowLog Controller
 * Extends the standard Record controller
 */
Espo.define('workflows:controllers/workflow-log', 'controllers/record', function (Dep) {
    return Dep.extend({
        // Use standard Record controller functionality
    });
});

