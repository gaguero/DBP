/**
 * WorkflowExecution Controller
 * Extends the standard Record controller
 */
Espo.define('workflows:controllers/workflow-execution', 'controllers/record', function (Dep) {
    return Dep.extend({
        // Use standard Record controller functionality
    });
});

