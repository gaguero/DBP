/**
 * WorkflowLog Controller
 * Extends the standard Record controller
 */
Espo.define('Workflows:Controllers.WorkflowLog', 'Controllers.Record', function (Dep) {
    return Dep.extend({
        // Use standard Record controller functionality
    });
});

