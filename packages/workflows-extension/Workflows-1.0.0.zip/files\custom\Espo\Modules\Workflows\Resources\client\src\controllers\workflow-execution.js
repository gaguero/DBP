/**
 * WorkflowExecution Controller
 * Extends the standard Record controller
 */
Espo.define('Workflows:Controllers.WorkflowExecution', 'Controllers.Record', function (Dep) {
    return Dep.extend({
        // Use standard Record controller functionality
    });
});

