<?php

use Espo\Core\Container;
use Espo\Core\Utils\Config;
use Espo\Core\Utils\Config\ConfigWriter;
use Espo\Core\Utils\Log;
use Espo\Core\Utils\Cache\ClearCache;
use Espo\Core\Utils\Rebuild\RebuildManager;
use Espo\Core\InjectableFactory;
use Espo\ORM\EntityManager;

return function (Container $container): void {
    /** @var Log $log */
    $log = $container->get('log');
    
    try {
        $log->info('FreeWorkflows: Starting installation process...');
        
        $config = $container->getByClass(Config::class);
        $configWriter = $container->getByClass(InjectableFactory::class)->create(ConfigWriter::class);
        
        // Add Workflow to tabList
        $tabList = $config->get('tabList') ?? [];
        if (!in_array('Workflow', $tabList, true)) {
            $tabList[] = 'Workflow';
            $configWriter->set('tabList', $tabList);
            $log->info('FreeWorkflows: Added Workflow to tabList');
        }
        
        // Add Workflow to quickCreateList
        $quickCreateList = $config->get('quickCreateList') ?? [];
        if (!in_array('Workflow', $quickCreateList, true)) {
            $quickCreateList[] = 'Workflow';
            $configWriter->set('quickCreateList', $quickCreateList);
            $log->info('FreeWorkflows: Added Workflow to quickCreateList');
        }
        
        $configWriter->save();
        $log->info('FreeWorkflows: Configuration saved successfully');
        
        // Clear cache
        $cacheClearer = $container->getByClass(ClearCache::class);
        $cacheClearer->clearAll();
        $log->info('FreeWorkflows: Cache cleared');
        
        // Rebuild metadata and clientDefs (full rebuild to ensure client files are transpiled)
        $rebuildManager = $container->getByClass(RebuildManager::class);
        $rebuildManager->rebuild(false);
        $log->info('FreeWorkflows: Rebuild completed');
        
        // Force client rebuild by clearing client cache
        $fileManager = $container->get('fileManager');
        $clientCachePath = 'data/cache/application/client';
        if ($fileManager->isDir($clientCachePath)) {
            $fileManager->removeInDir($clientCachePath);
            $log->info('FreeWorkflows: Client cache cleared');
        }
        
        // Verify scheduled jobs were created (they should be created automatically during rebuild)
        $entityManager = $container->getByClass(EntityManager::class);
        $scheduledJobs = [
            'ProcessWorkflowExecution',
            'ProcessScheduledWorkflow',
            'ProcessRecurringWorkflow',
        ];
        
        foreach ($scheduledJobs as $jobName) {
            $job = $entityManager
                ->getRDBRepository('ScheduledJob')
                ->where(['job' => $jobName])
                ->findOne();
            
            if ($job) {
                $log->info("FreeWorkflows: Scheduled job '{$jobName}' verified");
            } else {
                $log->warning("FreeWorkflows: Scheduled job '{$jobName}' not found (may be created on next cron run)");
            }
        }
        
        $log->info('FreeWorkflows: Installation completed successfully');
        
    } catch (\Throwable $e) {
        $log->error('FreeWorkflows: Installation failed: ' . $e->getMessage());
        $log->error('FreeWorkflows: Stack trace: ' . $e->getTraceAsString());
        throw $e;
    }
};
