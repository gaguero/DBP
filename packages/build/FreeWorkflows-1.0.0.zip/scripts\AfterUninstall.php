<?php

use Espo\Core\Container;
use Espo\Core\Utils\Config;
use Espo\Core\Utils\Config\ConfigWriter;
use Espo\Core\Utils\Log;
use Espo\Core\Utils\Cache\ClearCache;
use Espo\Core\Utils\Rebuild\RebuildManager;
use Espo\Core\InjectableFactory;
use Espo\ORM\EntityManager;

return function (Container $container): void {
    /** @var Log $log */
    $log = $container->get('log');
    
    try {
        $log->info('FreeWorkflows: Starting uninstallation process...');
        
        $config = $container->getByClass(Config::class);
        $configWriter = $container->getByClass(InjectableFactory::class)->create(ConfigWriter::class);
        
        // Remove Workflow from tabList
        $tabList = array_values(array_filter(
            $config->get('tabList') ?? [],
            fn ($item): bool => $item !== 'Workflow' && (!is_object($item) || $item->text !== 'Workflow')
        ));
        $configWriter->set('tabList', $tabList);
        $log->info('FreeWorkflows: Removed Workflow from tabList');
        
        // Remove Workflow from quickCreateList
        $quickCreateList = array_values(array_filter(
            $config->get('quickCreateList') ?? [],
            fn (string $item): bool => $item !== 'Workflow'
        ));
        $configWriter->set('quickCreateList', $quickCreateList);
        $log->info('FreeWorkflows: Removed Workflow from quickCreateList');
        
        $configWriter->save();
        $log->info('FreeWorkflows: Configuration updated successfully');
        
        // Remove scheduled jobs created by this extension
        $entityManager = $container->getByClass(EntityManager::class);
        $scheduledJobs = [
            'ProcessWorkflowExecution',
            'ProcessScheduledWorkflow',
            'ProcessRecurringWorkflow',
        ];
        
        foreach ($scheduledJobs as $jobName) {
            $job = $entityManager
                ->getRDBRepository('ScheduledJob')
                ->where(['job' => $jobName])
                ->findOne();
            
            if ($job) {
                $entityManager->removeEntity($job);
                $log->info("FreeWorkflows: Removed scheduled job '{$jobName}'");
            }
        }
        
        // Clear cache
        $cacheClearer = $container->getByClass(ClearCache::class);
        $cacheClearer->clearAll();
        $log->info('FreeWorkflows: Cache cleared');
        
        // Rebuild metadata
        $rebuildManager = $container->getByClass(RebuildManager::class);
        $rebuildManager->rebuild(false);
        $log->info('FreeWorkflows: Rebuild completed');
        
        $log->info('FreeWorkflows: Uninstallation completed successfully');
        
        // Note: Workflow, WorkflowExecution, and WorkflowLog entities and their data
        // will remain in the database. They can be manually deleted if needed.
        $log->info('FreeWorkflows: Note - Workflow entities remain in database. Delete manually if needed.');
        
    } catch (\Throwable $e) {
        $log->error('FreeWorkflows: Uninstallation failed: ' . $e->getMessage());
        $log->error('FreeWorkflows: Stack trace: ' . $e->getTraceAsString());
        throw $e;
    }
};
